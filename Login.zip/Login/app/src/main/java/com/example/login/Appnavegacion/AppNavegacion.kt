package com.example.Login.Appnavegacion

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.login.Screens.ChatScreen
import com.example.login.Screens.LoginScreen

// ── Rutas de navegación ──
object Rutas {
    const val LOGIN = "login"
    const val CHAT  = "chat"
    // Cuando agregues más pantallas las pones aquí:
    // const val HOME     = "home"
    // const val REGISTRO = "registro"
}

@Composable
fun AppNavegacion() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Rutas.LOGIN
    ) {

        // ── 1. Login ──
        composable(Rutas.LOGIN) {
            LoginScreen(
                onLoginClick = {
                    navController.navigate(Rutas.CHAT) {
                        popUpTo(Rutas.LOGIN) { inclusive = true }
                    }
                },
                onSignUpClick = {
                    // Cuando tengas RegistroScreen:
                    // navController.navigate(Rutas.REGISTRO)
                    navController.navigate(Rutas.CHAT) {
                        popUpTo(Rutas.LOGIN) { inclusive = true }
                    }
                },
                onForgotPasswordClick = {
                    // Aquí irá navegación a recuperar contraseña
                }
            )
        }

        // ── 2. Chat ──
        composable(Rutas.CHAT) {
            ChatScreen(
                onHomeClick = {
                    // Cuando tengas HomeScreen:
                    // navController.navigate(Rutas.HOME)
                }
            )
        }
    }
}