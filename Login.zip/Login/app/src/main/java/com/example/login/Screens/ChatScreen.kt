package com.example.login.Screens


import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Compass
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.login.R

// ── Colores ──
private val MoradoPrincipal = Color(0xFF7B2FBE)
private val MoradoClaro     = Color(0xFF9B30D9)
private val FondoOscuro     = Color(0xFF1A1A1A)
private val BurbujaOtro     = Color(0xFFE0E0E0)
private val TextoOscuro     = Color(0xFF1A1A1A)
private val TextoGris       = Color(0xFF888888)
private val BarraInferior   = Color(0xFF2A2A2A)

// ── Modelo de mensaje ──
data class Mensaje(
    val texto: String = "",
    val hora: String = "3:67 p.m",
    val esPropio: Boolean = false,
    val tieneImagen: Boolean = false,
    val imagenRes: Int? = null
)

@Composable
fun ChatScreen(
    onHomeClick: () -> Unit = {},
    onBackClick: () -> Unit = {}
) {
    var mensajeTexto by remember { mutableStateOf("") }

    // Lista de mensajes de ejemplo
    val mensajes = remember {
        listOf(
            Mensaje(texto = "Nuevo diseño de album :)", hora = "3:67 p.m", esPropio = false),
            Mensaje(hora = "3:67 p.m", esPropio = false, tieneImagen = true, imagenRes = R.drawable.album_queen),
            Mensaje(texto = "Wooooooooow\nla mejor banda, esperando\npor el proximo album.\ncuando sacaran gira ?", hora = "3:67 p.m", esPropio = false),
            Mensaje(texto = "Gracias quedo genial", hora = "3:67 p.m", esPropio = true)
        )
    }

    val listState = rememberLazyListState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FondoOscuro)
    ) {

        // ── TopBar ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MoradoPrincipal)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Group,
                contentDescription = "Grupo",
                tint = Color.White,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Queen",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = {}) {
                Icon(
                    imageVector = Icons.Filled.VideoCall,
                    contentDescription = "Video",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
            IconButton(onClick = {}) {
                Icon(
                    imageVector = Icons.Filled.Call,
                    contentDescription = "Llamar",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        // ── Lista de mensajes ──
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 16.dp)
        ) {
            items(mensajes) { mensaje ->
                if (mensaje.esPropio) {
                    MensajePropio(mensaje)
                } else {
                    MensajeOtro(mensaje)
                }
            }
        }

        // ── Input de mensaje ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(FondoOscuro)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = mensajeTexto,
                onValueChange = { mensajeTexto = it },
                placeholder = {
                    Text(text = "Mensaje", color = TextoGris)
                },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(28.dp)),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF2E2E2E),
                    unfocusedContainerColor = Color(0xFF2E2E2E),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = MoradoClaro
                ),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(10.dp))
            // Botón micrófono
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(MoradoClaro),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Mic,
                    contentDescription = "Micrófono",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        // ── Barra de navegación inferior ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BarraInferior)
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onHomeClick) {
                Icon(Icons.Filled.Home, contentDescription = "Inicio", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = {}) {
                Icon(Icons.Filled.Bookmark, contentDescription = "Guardados", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = {}) {
                Icon(Icons.Filled.Compass, contentDescription = "Explorar", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = {}) {
                Icon(Icons.Filled.ChatBubble, contentDescription = "Chats", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = {}) {
                Icon(Icons.Filled.AddCircle, contentDescription = "Agregar", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }
    }
}

// ── Burbuja de mensaje de otro usuario ──
@Composable
fun MensajeOtro(mensaje: Mensaje) {
    Row(
        verticalAlignment = Alignment.Bottom,
        modifier = Modifier.fillMaxWidth()
    ) {
        // Avatar
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Color(0xFF555555)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Group,
                contentDescription = "Avatar",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Burbuja
        Box(
            modifier = Modifier
                .widthIn(max = 260.dp)
                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 20.dp))
                .background(BurbujaOtro)
                .padding(12.dp)
        ) {
            Column {
                if (mensaje.tieneImagen && mensaje.imagenRes != null) {
                    Image(
                        painter = painterResource(id = mensaje.imagenRes),
                        contentDescription = "Imagen",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                } else if (mensaje.texto.isNotEmpty()) {
                    Text(
                        text = mensaje.texto,
                        color = TextoOscuro,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Text(
                    text = mensaje.hora,
                    color = TextoGris,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

// ── Burbuja de mensaje propio ──
@Composable
fun MensajePropio(mensaje: Mensaje) {
    Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.End,
        modifier = Modifier.fillMaxWidth()
    ) {
        // Burbuja propia
        Box(
            modifier = Modifier
                .widthIn(max = 260.dp)
                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 4.dp, bottomStart = 20.dp, bottomEnd = 20.dp))
                .background(MoradoClaro)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Column {
                Text(
                    text = mensaje.texto,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = mensaje.hora,
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Avatar propio
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Color(0xFF555555)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Group,
                contentDescription = "Avatar",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ChatScreenPreview() {
    ChatScreen()
}